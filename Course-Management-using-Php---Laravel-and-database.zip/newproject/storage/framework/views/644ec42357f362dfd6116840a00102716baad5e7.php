<?php $__env->startSection('title', 'Page Title'); ?>



<?php $__env->startSection('content'); ?>
    <p>This is my body content</p>
    <h1>About</h1>

<?php echo e($myname); ?></br>
<?php echo e($id); ?></br>
<?php echo e($phone); ?></br>




<p>Inside about page :D :D :D 
</p>
<?php for($i=1 ; $i<11 ; $i++): ?>
The current value is <?php echo e($i); ?></br>
<?php endfor; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<h1>Footer</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>