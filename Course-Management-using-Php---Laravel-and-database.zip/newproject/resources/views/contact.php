<!DOCTYPE html>
<html>
<head>
	<title>Contact Page</title>
</head>
<body>
<h1>Contact Page</h1>
<p>So this is a really big deal in terms of global power dynamics; there was a lot of rapid reporting and writing done late Sunday by our team in China, including Chris Buckley, a proud product of Sydney. This is a story worth following as is Chris's </p>
</body>
</html> 