
<!DOCTYPE html>
<html>
<head>
	<title>ALL Course </title>
	<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
<div class="row">
		<div class="span5">
            <table able class="table table-striped table-condensed">
                  <thead>
                  <tr>
                      <th>Course Title</th>
                      <th>Course Code</th>
                      <th>Course Credit</th>
                      <th>Action</th>                                          
                  </tr>
              </thead>                 <tbody>
              	
              	@foreach($alldata as $data)
                <tr>
                    <td>{{$data->course_title}}</td>
                    <td>{{$data->course_code}}</td>
                    <td>{{$data->course_credit}}</td>
                    <td> <a href="{{route('course.edit',$data->course_id)}}" class="btn btn-info">Edit</a>
                    </td>                                       
                    {!!Form::hidden('id',$data->course_id) !!}  
                </tr>

               @endforeach 
                                                  
              </tbody> 
            </table>   
            </div>

	</div>
</div>

 </body>
</html>