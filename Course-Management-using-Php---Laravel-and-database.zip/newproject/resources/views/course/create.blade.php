
<!DOCTYPE html>
<html>
<head>
	<title>Add Course </title>
	<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css>
</head>
<body>

<div class="container">
 
<div class="col-sm-5">
	{!! Form::open(array('route' => 'course.store'))!!}
	
	{!!Form::token();!!}
	
            <div class="panel panel-default">
                <div class="panel-body form-horizontal payment-form">
                    <div class="form-group">
                        <label for="concept" class="col-sm-3 control-label">Course Title</label>
                        <div class="col-sm-9">
                        
      <input type="text" class="form-control" id="concept" name="course_title" required >
                      </div>
                    </div>
                    
                 

                  <div class="form-group">
                        <label for="description" class="col-sm-3 control-label">Course Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="description" name="course_code" required="">
                        </div>
                    </div> 
                 


                    <div class="form-group">
                        <label for="amount" class="col-sm-3 control-label">Course Credit</label>
                        <div class="col-sm-9">
                            <input type="text" class=" form-control" id="amount" name="course_credit" required="" >
                        </div>
                    </div
                   
              
               </div>
                        
                   
  {!! Form::submit('Submit',$attributes= array('btn btn-info')) !!}
            </div>            
            {!! Form::close() !!}
        </div>

</div>

</body>
</html>