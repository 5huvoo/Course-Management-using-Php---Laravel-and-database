<!DOCTYPE html>
<html>
<head>
	<title>All Users Page</title>
</head>
<body>
	  <h1>Users</h1>
	  <p>Nawaz</p>
	  <p>Azmeer</p>
	  <p>Jeem</p>
</body>
</html>