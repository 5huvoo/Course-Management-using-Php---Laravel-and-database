@extends('layouts.master')

@section('title', 'Page Title')



@section('content')
    <p>This is my body content</p>
    <h1>About</h1>

{{$myname}}</br>
{{$id}}</br>
{{$phone}}</br>




<p>Inside about page :D :D :D 
</p>
@for($i=1 ; $i<11 ; $i++)
The current value is {{$i}}</br>
@endfor
@endsection

@section('footer')
<h1>Footer</h1>
@endsection