<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Course;

class CourseController extends Controller
{
    //
	public function index()
	{
		//return "hello here is the data";
		$alldata= Course::all();
		return view('course.index',compact('alldata'));
	}

	

  public function create()

	     {
		      return view('course.create');
	     }

	public function store(Request $request)

	     {
		      $input= $request->all();

		      Course::create($input);

		      return redirect('course');
/*
       $course_title = $request-> input('course_title');
       $course_name = $request-> input('course_name');
       $course_credit = $request-> input('course_credit');

       return $course_code; */
      }

   public function show()

       {
   	        return view('course.index');
       }

public function edit($id)

   {   
   //	return view('course.edit');
   //return $id ;

$course = Course::where('course_id',$id)->first();
//return $course;
return view('course.edit',compact('course'));
   //	return "Edit page";
   }

   public function update(Request $request,$id)
   {
    $input= $request->all();
    Course::where('course_id', $id)
    ->update([
      'course_title' => $input['course_title'],
      'course_credit'=>$input['course_credit'],
      'course_code'=>$input['course_code']
    ]);
    return redirect('course') ;
   }
}
