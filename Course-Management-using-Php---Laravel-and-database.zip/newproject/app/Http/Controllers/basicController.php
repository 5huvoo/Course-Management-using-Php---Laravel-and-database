<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class basicController extends Controller
{
 
public function index(){

    	//return view('home');
    	return "Home Basic Controller";
    }

    public function about(){
        $myname="SHUVO THE BOSS :D ";
        $id="123093";
        $phone="987987645322";
        $address="Bogra";
    	return view('about',compact('myname','id','phone'))->with('hometown','$address');
    	//return "Home Basic Controller";
    }

    //
}
